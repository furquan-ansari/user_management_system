// userController.js

// const User = require('../models/User');
// const bcrypt = require('bcrypt');
// exports.createUser = async (req, res) => {
//   const { username, password, roleId } = req.body;
//   try {

//     const hashedPassword = await bcrypt.hash(password, 10);
//     console.log(hashedPassword);
//     const user = await User.create({ username, password:hashedPassword, roleId });
//     res.status(201).json(user);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Failed to create user" });
//   }
// };

// exports.updateUser = async (req, res) => {
//   const { id } = req.params;
//   const { username, password, roleId } = req.body;
//   try {
//     const user = await User.findByPk(id);
//     if (!user) {
//       return res.status(404).json({ message: "User not found" });
//     }
//     user.username = username;
//     user.password = password;
//     user.roleId = roleId;
//     await user.save();
//     res.status(200).json(user);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Failed to update user" });
//   }
// };

// exports.deleteUser = async (req, res) => {
//   const { id } = req.params;
//   try {
//     const user = await User.findByPk(id);
//     if (!user) {
//       return res.status(404).json({ message: "User not found" });
//     }
//     await user.destroy();
//     res.status(200).json({ message: "User deleted successfully" });
//     res.status(204).end();
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Failed to delete user" });
//   }
// };



/* -------------------For Test---------------------------- */

const User = require('../models/User');
const bcrypt = require('bcrypt');

exports.createUser = async (req, res) => {
  const { username, password, isAdmin } = req.body;
  try {

    const hashedPassword = await bcrypt.hash(password, 10);
    console.log(hashedPassword);
    const user = await User.create({ username, password:hashedPassword, isAdmin });
    res.status(201).json(user);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to create user" });
  }
};

exports.updateUser = async (req, res) => {
  const { id } = req.params;
  const { username, password, isAdmin } = req.body;
  try {
    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    user.username = username;
    user.password = password;
    user.isAdmin = isAdmin;
    await user.save();
    res.status(200).json(user);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to update user" });
  }
};

exports.deleteUser = async (req, res) => {
  const { id } = req.params;
  try {
    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    await user.destroy();
    res.status(200).json({ message: "User deleted successfully" });
    res.status(204).end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to delete user" });
  }
};

// Access.js

// models/access.js
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/dbConfig'); // Adjust the path as per your project structure

const Access = sequelize.define('Access', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  page: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  tableName: 'accesses' // Specify the table name if it's different from the pluralized model name
});

module.exports = Access;

// Role.js

const {Sequelize, DataTypes} = require('sequelize');
const sequelize = require('../config/dbConfig');

const Role = sequelize.define('role', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  }
},{
    tableName: 'roles' // Specify the table name if it's different from the pluralized model name
  }
);

module.exports = Role;

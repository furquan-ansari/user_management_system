import React from 'react';
import './HomePage.css'; // Import the CSS file

class HomePage extends React.Component {
  render() {
    return (
      <div className="container">
        <header>
          <h1>Welcome to My Website</h1>
        </header>
        <main>
          <section>
            <h2>About Us</h2>
            <p>This is a simple home page built using React.js.</p>
          </section>
          <section>
            <h2>Services</h2>
            <p>We offer various services to meet your needs.</p>
          </section>
          <section>
            <h2>Contact Us</h2>
            <p>Get in touch with us for any inquiries or feedback.</p>
          </section>
        </main>
        <footer>
          <p>&copy; 2024 My Website. All rights reserved.</p>
        </footer>
      </div>
    );
  }
}

export default HomePage;

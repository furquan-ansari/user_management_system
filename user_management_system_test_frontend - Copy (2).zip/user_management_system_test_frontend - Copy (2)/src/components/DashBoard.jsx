import React, { useState } from 'react';

// data
const empData = [
  {
    _id: 1,
    name: "John Doe",
    mob: 1112223330,
    email: "john@abc.com",
    position: "Accountant",
    dept: "IT",
    sal: 15000,
    status: "Active"
  },
  // other employee objects...
];

// popup component
const Popmodal = ({ children, showModal, newAdd, onClose, onSubmit, defaultProps }) => {
//   const [mob, setMob] = useState(children.mob);

/*   const handleMobileChange = (e) => {
    setMob(e.target.value);
  }; */

/*   const handleNewAddChanges = (e) => {
    setMob(e.target.value);
  }; */

/*   const handleNewSubmit = (e) => {
    onSubmit(
      { ...children, mob },
      e,
      null,
      "new",
      defaultProps.currentID
    );
  }; */

  return children && !!!newAdd ? (
    <div className={showModal ? "show" : "hide"}>
      {/* Popup content */}
    </div>
  ) : newAdd ? (
    <div className={showModal ? "show" : "hide"}>
      {/* Popup content for new addition */}
    </div>
  ) : null;
};

// employee component
const Employee = ({ empDetRow, handleNewAdd }) => {
  const getEmpDets = (empDetRow) => {
    return empDetRow ? empDetRow : "....No Data Available";
  };

  return (
    <div>
      Emp details :{JSON.stringify(getEmpDets(empDetRow))}
      <br />
      <button
        className="btn btn-success btn-sm"
        style={{ margin: "10px", left: "40%", position: "relative" }}
        onClick={(e) => handleNewAdd(e)}
      >
        Add
      </button>
    </div>
  );
};

// employees component
const Employees = ({ empData, handleDelete, handleTableClick, handleEdit }) => {
//   const cellButton = (cell, row, enumObject, rowIndex) => {
//     return (
//       <div>
//         {/* Button content */}
//       </div>
//     );
//   };

  return (
    <div className="container">
      {/* Bootstrap Table */}
    </div>
  );
};

// main app component
const Dashboard = () => {
  const [state, /* setState */] = useState({
    empData: empData,
    empDetRow: empData[0],
    showModal: false,
    newAdd: false
  });

  const handleTableClick = (row) => {
    // Handle table click
  };

  const handleDelete = (row) => {
    // Handle delete
  };

  const handleEdit = (row) => {
    // Handle edit
  };

  const onClose = (e) => {
    // Handle close
  };

  const handleNewAdd = (e) => {
    // Handle new add
  };

  const onSubmit = (data, e, currentRow, newEditFlag, currentID) => {
    // Handle form submission
  };

  return (
    <div>
      <h1> Bootstrap Table.....</h1>
      <Employees
        empData={state.empData}
        handleDelete={handleDelete}
        handleTableClick={handleTableClick}
        handleEdit={handleEdit}
      />

      <br />
      <Employee
        empDetRow={state.empDetRow}
        handleNewAdd={handleNewAdd}
      />

      <br />
      <Popmodal
        defaultProps={Dashboard.defaultProps}
        showModal={state.showModal}
        newAdd={state.newAdd}
        onClose={onClose}
        onSubmit={onSubmit}
      >
        {state.empDetRow}
      </Popmodal>
    </div>
  );
};

export default Dashboard;

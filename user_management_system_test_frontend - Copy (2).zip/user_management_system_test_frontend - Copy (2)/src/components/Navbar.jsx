import React from "react";
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav>
      <Link to="/Home">HomePage</Link>
      <Link to="/Login">Login</Link>
      <Link to="/Dashboard">DashBoard</Link>
    </nav>
  );
}

export default Navbar;

// import logo from './logo.svg';
// import './App.css';

// function App() {
//  return(
//   <h1>Hello world......</h1>
//  )
// }

// export default App;

////////////////////////////////////////////////////////////////////////////////

import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import './App.css';
import Login from "./components/Login";
import "../src/components/Login.css";
import HomePage from "../src/components/HomePage.jsx";
import "../src/components/HomePage.jsx";
import Navbar from "../src/components/Navbar.jsx";
import "../src/components/Navbar.css";
import DashBoard from "../src/components/DashBoard.jsx";
import "../src/components/DashBoard.css";

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/Home" element={<HomePage />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/Dashboard" element={<DashBoard />} />
      </Routes>
    </Router>
  );
}

export default App;

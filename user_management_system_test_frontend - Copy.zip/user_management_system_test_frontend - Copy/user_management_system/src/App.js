// import logo from './logo.svg';
// import './App.css';

// function App() {
//  return(
//   <h1>Hello world......</h1>
//  )
// }

// export default App;



import React from 'react';
import './App.css';
import Login from './components/Login';


function App() {
  return (
   <Login/>
  );
}

export default App;
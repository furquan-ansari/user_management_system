// dbConfig.js

// const Sequelize = require('sequelize');

// const sequelize = new Sequelize('user_management_system', 'root', 'root', {
//   host: 'localhost',
//   dialect: 'mysql'
// });

// sequelize.sync()
//   .then(() => {
//     console.log('All models were synchronized successfully.');
//   })
//   .catch(err => {
//     console.error('Error synchronizing models:', err);
//   });


// module.exports = sequelize;



/* --------------------------For Test-------------------------------- */

const Sequelize = require('sequelize');

const sequelize = new Sequelize('user_management_system_test', 'root', 'root', {
  host: 'localhost',
  dialect: 'mysql'
});

sequelize.sync()
  .then(() => {
    console.log('All models were synchronized successfully.');
  })
  .catch(err => {
    console.error('Error synchronizing models:', err);
  });


module.exports = sequelize;
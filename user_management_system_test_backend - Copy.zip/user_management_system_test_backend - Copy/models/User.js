// User.js

// const {Sequelize, DataTypes} = require('sequelize');
// const sequelize = require('../config/dbConfig');

// const User = sequelize.define('user', {
//   id: {
//     type: DataTypes.INTEGER,
//     autoIncrement: true,
//     primaryKey: true
//   },
//   username: {
//     type: DataTypes.STRING,
//     allowNull: false,
//     unique: true
//   },
//   password: {
//     type: DataTypes.STRING,
//     allowNull: false
//   },
//   roleId: {
//     type: DataTypes.INTEGER,
//     allowNull: false
//   }
// },{
//   tableName: 'users' // Specify the table name if it's different from the pluralized model name
// }
// );

// module.exports = User;



/* ---------------------------For Test------------------------ */


const {Sequelize, DataTypes} = require('sequelize');
const sequelize = require('../config/dbConfig');

const User = sequelize.define('user', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  username: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
  isAdmin: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  }
},{
  tableName: 'users' // Specify the table name if it's different from the pluralized model name
}
);

module.exports = User;

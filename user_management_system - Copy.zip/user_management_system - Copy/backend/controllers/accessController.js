// accessController.js

const Access = require('../models/Access');

exports.createAccess = async (req, res) => {
  const { userId, page } = req.body;
  try {
    const access = await Access.create({ userId, page });
    res.status(201).json(access);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to create access" });
  }
};

exports.updateAccess = async (req, res) => {
  const { id } = req.params;
  const { page } = req.body;
  try {
    const access = await Access.findByPk(id);
    if (!access) {
      return res.status(404).json({ message: "Access not found" });
    }
    access.page = page;
    await access.save();
    res.status(200).json(access);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to update access" });
  }
};

exports.deleteAccess = async (req, res) => {
  const { id } = req.params;
  try {
    const access = await Access.findByPk(id);
    if (!access) {
      return res.status(404).json({ message: "Access not found" });
    }
    await access.destroy();
    res.status(204).end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to delete access" });
  }
};

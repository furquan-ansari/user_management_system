// Access.js

const Sequelize = require('sequelize');
const sequelize = require('../config/dbConfig');

const Access = sequelize.define('access', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  userId: {
    type: Sequelize.INTEGER,
    allowNull: false
  },
  page: {
    type: Sequelize.STRING,
    allowNull: false
  }
});

module.exports = Access;

// accessRoutes.js

const express = require('express');
const router = express.Router();
const accessController = require('../controllers/accessController');

router.post('/', accessController.createAccess);
router.put('/:id', accessController.updateAccess);
router.delete('/:id', accessController.deleteAccess);

module.exports = router;


// dbConfig.js

const Sequelize = require('sequelize');

const sequelize = new Sequelize('user_management_system', 'localhost', 'root', {
  host: 'localhost',
  dialect: 'mysql'
});

module.exports = sequelize;
